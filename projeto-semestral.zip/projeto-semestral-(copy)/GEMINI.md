# Gemini Project Context: Godot Game

## Project Overview

This is a 2D game developed using the Godot Engine (version 4.5 with GL Compatibility). The player controls a cat character to navigate a map, collect items (fish), and avoid enemies. The game ends if the player is caught by an enemy.

The project is structured using Godot's scene and script system. GDScript (`.gd`) is the programming language used for game logic.

### Key Files
*   `project.godot`: The main Godot project configuration file. It specifies the main scene and autoloads the global script.
*   `Projeto_faculdade.tscn`: This is likely the main scene where the game starts.
*   `gerenciador_global_script.gd`: An autoloaded singleton script that manages the game's global state, primarily tracking the total number of collectibles and how many have been collected.
*   `script_gato.gd`: The script for the player character ("gato"). It handles player movement (via keyboard input `ui_right`, `ui_left`, `ui_up`, `ui_down`) and animations. It also contains logic for what happens when the player "dies".
*   `script_inimigo.gd`: The script for enemy characters. It defines a patrol path for the enemy and triggers a game over if it collides with the player.
*   `script_item_coletavel.gd`: The script for collectible items. When the player collects an item, it notifies the `GerenciadorGlobalScript` and disappears.
*   `cena_*.tscn`: These are Godot scene files, which represent different game elements like the player, enemies, items, and UI screens (e.g., `cena_game_over.tscn`).

## Building and Running

This is a Godot project. There are no command-line build scripts evident in the project structure.

1.  **Open the project:** Download and install the Godot Engine (version 4.5 or compatible).
2.  In the Godot Project Manager, click "Import" or "Scan" and select the project's root folder.
3.  Once the project is loaded, you can run the game by clicking the "Play" button (or pressing F5). The main scene is configured to run by default.

## Development Conventions

*   **Global State:** The project uses an autoloaded script (`GerenciadorGlobalScript`) to manage global game state, such as the number of collectibles.
*   **Signaling/Events:** Scripts appear to use Godot's built-in signals (like `body_entered`) for collision detection and interaction between game objects.
*   **Scene-based Logic:** Logic is encapsulated within scripts that are attached to specific scenes (e.g., the enemy logic is in `script_inimigo.gd` which is likely attached to an enemy scene).
*   **Naming:** The file and node naming is in Portuguese (e.g., "gato" for cat, "inimigo" for enemy, "item_coletavel" for collectible item).
